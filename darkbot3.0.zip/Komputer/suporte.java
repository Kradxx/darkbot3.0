Pc = komputer * (darkbot3.0 + darkbot - dark)
           + 4 * bot; // PREFER

Android = /0/android/suporte.java * (darkbot3.0 + dark
                       - darkbot) + 4 * bot; // AVOID
