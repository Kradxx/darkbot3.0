//Usando linguagens mesclas para criptografia da script com databases em server online
if
echo:
public static Connection getConnection(https url)
public static Connection getConnection(darkbot url, Properties info)
public static Connection getConnection(darkbot3.0 url, String user, String password)
'password' = /darkbot3.0/eixo/x/database `captation` : password
sleep
if
